//papo__video
setTimeout(function(){

	var iframe = '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/nktSYpjl8ow?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';
	var papo__video = document.querySelector('.papo__video');
	if (papo__video) papo__video.innerHTML = iframe;

}, 100);

//videos__list
setTimeout(function(){

	var videos__list = '<div class="videos__item col-md col-12"><div class="videos__item--title"><h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div><div class="videos__item col-md col-12"> <div class="videos__item--title"> <h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div><div class="videos__item col-md col-12"> <div class="videos__item--title"> <h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div><div class="videos__item col-md col-12"> <div class="videos__item--title"> <h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div><div class="videos__item col-md col-12"> <div class="videos__item--title"> <h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div><div class="videos__item col-md col-12"> <div class="videos__item--title"> <h4>PAPO 13 - VANESSA COUTINHO</h4> </div><div class="videos__item--frame"> <iframe width="100%" height="100%" src="https://www.youtube.com/embed/OxJmC5DSwT4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> </div></div>';
	var videos__items = document.querySelector('.videos__list');
	if (videos__items) videos__items.innerHTML = videos__list;

}, 600);